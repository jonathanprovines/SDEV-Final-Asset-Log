#Asset Log Program
#Created by Jonathan Provines
#Ver 1.0, Released 2021.12.14

#Imports necessary modules
from breezypythongui import EasyFrame
from tkinter import PhotoImage
import os
#specifies path to usermanual
userManualPath = 'AssetLogManual.docx'
#initializes records list
records = list("")
#Defines Class for window
class Screen(EasyFrame):
    def __init__(self):
        #Opens Initial Home Window
        EasyFrame.__init__(self, title = "Asset Log")
        #Frame Label
        self.addLabel(text="Asset Log", row=0, column=0, columnspan=3, sticky="NSEW")
        #Clip Art Image
        imageLabel = self.addLabel(text="", row=1, column=0, columnspan=3, rowspan=3, sticky="NSEW")
        self.image = PhotoImage(file="homephoto.gif")
        imageLabel["image"] = self.image
        #Navigation Buttons
        self.addButton(text="Sign-Out Asset", row=4, column=0, command=self.signOut)
        self.addButton(text="Sign-In Asset", row=4, column=1, command=self.signIn)
        self.addButton(text="View Assets Out", row=4, column=2, command=self.list)
        self.addButton(text="Open User Manual in Word", row=5,column=0, columnspan=3, command=self.launchUserManual)
    def homeScreen(self): #Home Screen when returning from other windows
        #closes previous frame
        self.destroy()
        #Creates new frame
        EasyFrame.__init__(self, title="Asset Log")
        # Frame Label
        self.addLabel(text="Asset Log", row=0, column=0, columnspan=3, sticky="NSEW")
        # Clip Art Image
        imageLabel = self.addLabel(text="",row=1, column=0,columnspan=3,rowspan=3, sticky="NSEW")
        self.image = PhotoImage(file="homephoto.gif")
        imageLabel["image"] = self.image
        # Navigation Buttons
        self.addButton(text="Sign-Out Asset", row=4, column=0, command=self.signOut)
        self.addButton(text="Sign-In Asset", row=4, column=1, command=self.signIn)
        self.addButton(text="View Assets Out", row=4, column=2, command=self.list)
        self.addButton(text="Open User Manual in Word", row=5, column=0, columnspan=3, command=self.launchUserManual)
    def signOut(self): #Signout Window
        # closes previous frame
        self.destroy()
        #Creates new frame
        EasyFrame.__init__(self, title="Asset Log")
        #Adds Field and title labels
        self.addLabel(text="Sign-Out Asset", row=0, column=0, columnspan=2, sticky="NSEW")
        self.addLabel(text="Type Name in First Last format", row=1,column=0)
        self.addLabel(text="Type 5 digit Asset # from asset tag", row=2, column=0)
        #Adds text input fields
        self.nameInput = self.addTextArea(text="", row=1, column=1)
        self.assetInput = self.addTextArea(text="", row=2, column=1)
        #Adds submition and navigation buttons
        self.addButton(text="Sign-Out", row=3, column=0, command=self.recordSignOut)
        self.addButton(text="Return to Home Screen", row=3, column=1, command=self.returnHome)
    def signIn(self): #Sign-in Window
        # closes previous frame
        self.destroy()
        # Creates new frame
        EasyFrame.__init__(self, title="Asset Log")
        # Adds Field and title labels
        self.addLabel(text="Sign-In Asset", row=0, column=0, columnspan=2, sticky="NSEW")
        self.addLabel(text="Type Name in First Last format", row=1, column=0)
        self.addLabel(text="Type 5 digit Asset # from asset tag", row=2, column=0)
        # Adds text input fields
        self.nameInput = self.addTextArea(text="", row=1, column=1)
        self.assetInput = self.addTextArea(text="", row=2, column=1)
        # Adds submition and navigation buttons
        self.addButton(text="Sign-In", row=3, column=0, command=self.recordSignIn)
        self.addButton(text="Return to Home Screen", row=3, column=1, command=self.returnHome)
    def list(self):
        # closes previous frame
        self.destroy()
        # Creates new frame
        EasyFrame.__init__(self, title="Asset Log")
        # Adds list and title labels
        self.addLabel(text="Assets Currently Signed-Out", row=0, column=0, columnspan=2, sticky="NSEW")
        self.addLabel(text=(records), row=4, column=0, rowspan=2, columnspan=2)
        # Clip Art Image
        imageLabel = self.addLabel(text="", row=1, column=0, columnspan=3, rowspan=3, sticky="NSEW")
        self.image = PhotoImage(file="logphoto.gif")
        imageLabel["image"] = self.image
        # Adds navigation button
        self.addButton(text="Return to Home Screen", row=6, column=0, columnspan=2, command=self.returnHome)
    def returnHome(self): #used to return to homescreen
        self.destroy() #destroys current frame
        self.homeScreen() #launches home frame

    def recordSignOut(self):
        assetLog = open("assetLog.txt",'w') #opens backup file
        newSignOutRecordName = self.nameInput.getText() #sets string from name field to variable
        newSignOutRecordName = (''.join(newSignOutRecordName.splitlines())) # Removes new line from string
        newSignOutRecordAsset = self.assetInput.getText()#sets string from Asset# field to variable
        newSignOutRecordAsset = (''.join(newSignOutRecordAsset.splitlines()))# Removes new line from string
        if newSignOutRecordName == "": #Checks if name field is blank
            self.messageBox(title="Name Error", message=("Name Can Not be left blank"))#Displays error window
        else:
            if newSignOutRecordAsset == "":#Checks if Asset# Field is blank
                self.messageBox(title="Asset# Error", message=("Asset# Can Not be left blank"))#Displays error window
            else:
                if len(newSignOutRecordAsset) == 5:#Checks if Asset# is correct length
                    # If Asset# is correct length
                    newSignOutRecord = newSignOutRecordName + " " + newSignOutRecordAsset # Joins Name and Asset into new string
                    newSignOutRecord =(''.join(newSignOutRecord.splitlines())) #Removes new line characters
                    # Adds Asset sign-out to list, updates backup file with current list
                    records.append(newSignOutRecord)
                    n = assetLog.write(str(records))
                    assetLog.close()
                    self.messageBox(title = "Success", message=("You have successfully signed-out asset# ")+newSignOutRecordAsset)# Removes new line from string
                # If Asset# is incorrect length
                else:
                    self.messageBox(title="Asset# Error",message=(newSignOutRecordAsset+(" is not 5 digits")))#Displays error window

    def recordSignIn(self):
        assetLog = open("assetLog.txt",'w')
        newSignInRecordName = self.nameInput.getText()#sets string from name field to variable
        newSignInRecordName = (''.join(newSignInRecordName.splitlines())) # Removes new line from string
        newSignInRecordAsset = self.assetInput.getText()#sets string from Asset# field to variable
        newSignInRecordAsset = (''.join(newSignInRecordAsset.splitlines()))  # Removes new line from string
        newSignInRecord = newSignInRecordName + " " + newSignInRecordAsset
        newSignInRecord = (''.join(newSignInRecord.splitlines()))
        if newSignInRecordName == "":#Checks if name field is blank
            self.messageBox(title="Name Error", message=("Name Can Not be left blank"))#Displays error window
        else:
            if newSignInRecordAsset == "": #Checks if Asset# Field is blank
                self.messageBox(title="Asset# Error", message=("Asset# Can Not be left blank"))#Displays error window
            else:
                if len(newSignInRecordAsset) == 5:#Checks if Asset# is correct length
                    # If Asset# is correct length
                    if newSignInRecord in records: #Checks to see if name has signed out Asset#
                        # Removes Asset sign-out from list, updates backup file with current list
                        records.remove(newSignInRecord)
                        n = assetLog.write(str(records))
                        assetLog.close()
                        self.messageBox(title="Success", message=("You have successfully signed-in asset# ") + newSignInRecordAsset)#Displays confirmation window
                    else:
                        self.messageBox(title="Error", message=(
                                    newSignInRecordName + " does not currently have " + newSignInRecordAsset + " signed out."))#Displays error window
                else:
                        self.messageBox(title="Asset# Error", message=(newSignInRecordAsset + (" is not 5 digits")))#Displays error window
    def launchUserManual(self): #Launches user manual in Microsoft Word
        os.startfile(userManualPath)


def main(): #Main function loop
    Screen().mainloop()

if __name__ == "__main__": #launches main loop, program will not run without
    main()